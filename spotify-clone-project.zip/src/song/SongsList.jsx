import React, { useContext, useEffect, useState } from "react";
import { MusicContext } from "../context/MusicContext";
import { GET_SONGS } from "../queries";
import Search from "../Search";
import Song from "./Song";
import MenuIcon from "@mui/icons-material/Menu";
import CloseIcon from "@mui/icons-material/Close";
import "./SongList.css"; 
import { useQuery } from "@apollo/client";

const SongsList = ({ toggleSidebar, setToggleSidebar, togglePlayer }) => {
  const { songs, setSongs, selectedPlaylist, search, currentSong } =
    useContext(MusicContext);
  const [filteredSongs, setFilteredSongs] = useState([]);
  const { loading, data } = useQuery(GET_SONGS, {
    variables: { playlistId: selectedPlaylist.id },
  });

  useEffect(() => {
    if (!loading && data && data.getSongs) {
      setSongs(data.getSongs);
    }
  }, [selectedPlaylist, data, loading]);

  const songsToDisplay = search.trim() !== "" ? filteredSongs : songs;

  return (
    <div
      className={`songs-list-container ${
        currentSong ? "with-player" : ""
      }`}
    >
      <div className="songs-list-header">
        <h2 className="songs-list-title">{selectedPlaylist.title}</h2>
        <div
          className="sidebar-toggle"
          onClick={() => setToggleSidebar(!toggleSidebar)}
        >
          {toggleSidebar ? <CloseIcon /> : <MenuIcon />}
        </div>
      </div>
      <Search songs={songs} setFilteredSongs={setFilteredSongs} />
      <div className="songs-list-content">
        {songsToDisplay.map((song) => {
          return <Song key={song._id} song={song} />;
        })}
        {data && filteredSongs.length === 0 && songsToDisplay.length === 0 && (
          <p className="search-results-message">No search results found</p>
        )}
      </div>
    </div>
  );
};

export default SongsList;
