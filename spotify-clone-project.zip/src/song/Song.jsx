import React, { useContext, useEffect, useRef } from "react";
import { MusicContext } from "../context/MusicContext";
import "./Song.css"; 

const formatDuration = (duration) => {
  const durationString = duration.toString();
  return `${durationString.charAt(0)}:${durationString.substring(1)}`;
};

const Song = ({ song }) => {
  const { title, photo, artist, duration } = song;
  const { currentSong, setCurrentSong, setSearch } = useContext(MusicContext);
  const songRef = useRef(null);

  useEffect(() => {
    if (song === currentSong) {
      const screenWidth = window.innerWidth;
      if (screenWidth > 640) {
        songRef.current.scrollIntoView({
          behavior: "smooth",
          block: "end",
        });
      }
    }
  }, [currentSong]);

  return (
    <div
      className={`song-container ${
        currentSong === song ? "active" : ""
      }`}
      onClick={() => {
        setCurrentSong(song);
        setSearch("");
      }}
      ref={songRef}
    >
      <div className="song-details-container">
        <img
          src={photo}
          alt={title}
          className="song-image"
        />
        <div className="song-details">
          <h4 className="song-title">{title}</h4>
          <p className="song-artist">{artist}</p>
        </div>
      </div>
      <div className="song-duration">{formatDuration(duration)}</div>
    </div>
  );
};

export default Song;
