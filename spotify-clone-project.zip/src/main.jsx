

import { ApolloClient, ApolloProvider, InMemoryCache } from "@apollo/client";
import React from "react";
import ReactDOM from "react-dom";
import App from "./App.jsx";
import { MusicProvider } from "./context/MusicContext.jsx";
import "./index.css";

const client = new ApolloClient({
  uri: "https://api.ss.dev/resource/api",
  cache: new InMemoryCache(),
});

ReactDOM.createRoot(document.getElementById("root")).render(
  <ApolloProvider client={client}>
    <MusicProvider>
      <App />
    </MusicProvider>
  </ApolloProvider>
);
